import './App.css';
import React, {  } from "react";
import ReactDOM from 'react-dom';

const ArrayId = [];
const ArrayMascota = [];
const ArrayDueño = [];
const ArrayFecha = [];
const ArrayHora = [];
const ArraySintomas = [];

function borrarCita() {

}



function crearCita(props) {
  return(
    <div className="cita">
    <p>Mascota: <span>{props.NombreMascota}</span></p>
    <p>Dueño: <span>{props.NombreDueño}</span></p>
    <p>Fecha: <span>{props.FechaCita}</span></p>
    <p>Hora: <span>{props.HoraCita}</span></p>
    <p>Sintomas: <span>{props.Sintomas}</span></p>
    <button className="button elimnar u-full-width" onClick={borrarCita}>Eliminar ×</button>
  </div>
  );
  }
  ReactDOM.render(<crearCita/>, document.getElementById("root"));

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <div id="root">
          <h1>ADMINISTRADOR DE PACIENTES</h1>
          <div className="container">
            <div className="row">
              <div className="one-half column">
                <h2>Crear mi Cita</h2>
                <form>
                  <label>Nombre Mascota</label>
                  <input type="text" name="mascota" className="u-full-width" placeholder="Nombre Mascota"></input>

                  <label>Nombre Dueño</label>
                  <input type="text" name="propietario" className="u-full-width" placeholder="Nombre dueño de la mascota"></input>
                
                  <label>Fecha</label>
                  <input type="date" name="fecha" className="u-full-width"></input>

                  <label>hora</label>
                  <input type="time" name="hora" className="u-full-width"></input>

                  <label>Sintomas</label>
                  <textarea name="sintomas" className="u-full-width"></textarea>

                  <button type="submit" className="u-full-width button-primary" onClick={crearCita}>Agregar Cita</button>
                </form>
              </div>
              <div className="one-half column">
                <h2>Administra tus citas</h2>
                <div className="cita">
                  <p>Mascota: <span>Nina</span></p>
                  <p>Dueño: <span>Martin</span></p>
                  <p>Fecha: <span>2021-08-05</span></p>
                  <p>Hora: <span>08:20</span></p>
                  <p>Sintomas: <span>Le duele la pierna</span></p>
                  <button className="button elimnar u-full-width" onClick={borrarCita}>Eliminar ×</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <script src="/static/js/bundle.js"></script><script src="/static/js/vendors~main.chunk.js"></script><script src="/static/js/main.chunk.js"></script>
      </header>
    </div>
  );
}

export default App;
